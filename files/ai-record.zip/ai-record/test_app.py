"""Offline end-to-end test with a fake GitHub API (no network)."""
import app as appmod
from fastapi.testclient import TestClient

FAKE = {
    "/users/dongin/repos": [
        {"full_name": "dongin/plantVision", "fork": False},
        {"full_name": "dongin/cellpose-bench", "fork": False},
        {"full_name": "dongin/forked-thing", "fork": True},
    ],
    "/repos/dongin/plantVision/commits": [
        {"sha": "a1b2c3d4", "commit": {"author": {"name": "Dongin", "email": "d@x", "date": "2026-08-02T10:00:00Z"},
         "message": "Add point cloud viewer\n\n🤖 Generated with [Claude Code](https://claude.com/claude-code)\n\nCo-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"}},
        {"sha": "b2c3d4e5", "commit": {"author": {"name": "Dongin", "email": "d@x", "date": "2026-08-05T10:00:00Z"},
         "message": "fix typo"}},
        {"sha": "c3d4e5f6", "commit": {"author": {"name": "Dongin", "email": "d@x", "date": "2026-09-01T10:00:00Z"},
         "message": "LLaVA pipeline\n\nCo-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"}},
    ],
    "/repos/dongin/cellpose-bench/commits": [
        {"sha": "d4e5f6a7", "commit": {"author": {"name": "Dongin (aider)", "email": "d@x", "date": "2026-07-20T10:00:00Z"},
         "message": "aider: benchmark script\n\nCo-authored-by: aider (gpt-4o) <aider@aider.chat>"}},
        {"sha": "e5f6a7b8", "commit": {"author": {"name": "Dongin", "email": "d@x", "date": "2026-07-22T10:00:00Z"},
         "message": "readme"}},
    ],
}

async def fake_get_json(c, url, **params):
    path = url.replace(appmod.API, "")
    if path.endswith("/commits") and params.get("page", 1) > 1:
        return []
    return FAKE[path]

def test_scan_public(monkeypatch):
    monkeypatch.setattr(appmod, "_get_json", fake_get_json)
    d = TestClient(appmod.app).get("/api/scan?user=dongin").json()
    assert d["repos_scanned"] == 2            # fork skipped
    assert d["total_commits"] == 5 and d["ai_commits"] == 3
    assert d["by_tool"] == {"Claude Code": 1, "GitHub Copilot": 1, "Aider": 1}
    assert d["tool_models"] == {"Claude Code": {"Claude Opus 4.5": 1}, "Aider": {"gpt-4o": 1}}
    assert d["by_month"]["2026-08"] == {"total": 2, "ai": 1}
    assert d["repos"][0]["repo"] == "dongin/plantVision" and d["repos"][0]["ratio"] == 0.667
