from trailers import parse_message


def tools(msg, **kw):
    return {(a.tool, a.model) for a in parse_message(msg, **kw)}


def test_claude_with_model():
    msg = "Fix race\n\n🤖 Generated with [Claude Code](https://claude.com/claude-code)\n\nCo-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
    assert tools(msg) == {("Claude Code", "Claude Opus 4.5")}


def test_claude_no_model():
    assert tools("x\n\nCo-Authored-By: Claude <noreply@anthropic.com>") == {("Claude Code", None)}


def test_marker_only():
    assert tools("x\n\nGenerated with Claude Code") == {("Claude Code", None)}


def test_copilot():
    msg = "x\n\nCo-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
    assert tools(msg) == {("GitHub Copilot", None)}


def test_copilot_swe_agent():
    msg = "x\n\nCo-authored-by: copilot-swe-agent[bot] <198982749+Copilot@users.noreply.github.com>"
    assert tools(msg) == {("GitHub Copilot", None)}


def test_aider_author():
    assert tools("aider: refactor", author_name="Dongin (aider)", author_email="d@x.com") == {("Aider", None)}


def test_aider_trailer_model():
    msg = "x\n\nCo-authored-by: aider (gpt-4o) <aider@aider.chat>"
    assert tools(msg) == {("Aider", "gpt-4o")}


def test_human_coauthor_ignored():
    msg = "x\n\nCo-authored-by: Jane Doe <jane@example.com>"
    assert tools(msg) == set()


def test_assisted_by():
    msg = "x\n\nAssisted-by: GitHub Copilot (claude-sonnet-4) <copilot@github.com>"
    assert tools(msg) == {("GitHub Copilot", "claude-sonnet-4")}


def test_multiple():
    msg = "x\n\nCo-authored-by: Copilot <c@github.com>\nCo-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>"
    assert tools(msg) == {("GitHub Copilot", None), ("Claude Code", "Claude Sonnet 4.6")}
